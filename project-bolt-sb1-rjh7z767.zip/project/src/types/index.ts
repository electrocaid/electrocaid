export interface FaceData {
  id: string;
  imageUrl: string;
  landmarks: any;
  embedding: number[];
  sourceFile: string;
  timestamp?: number;
  boundingBox: {
    x: number;
    y: number;
    width: number;
    height: number;
  };
}

export interface AnalysisReport {
  faces: FaceData[];
  totalFiles: number;
  processedFiles: number;
  timestamp: number;
}