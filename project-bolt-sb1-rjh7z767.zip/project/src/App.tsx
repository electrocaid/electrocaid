import React, { useState, useCallback } from 'react';
import { FileUploader } from './components/FileUploader';
import { FaceGrid } from './components/FaceGrid';
import { ExportOptions } from './components/ExportOptions';
import { FaceData, AnalysisReport } from './types';
import { Camera } from 'lucide-react';

function App() {
  const [faces, setFaces] = useState<FaceData[]>([]);
  const [selectedFace, setSelectedFace] = useState<FaceData | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [report, setReport] = useState<AnalysisReport | null>(null);

  const handleFilesSelected = useCallback(async (files: File[]) => {
    setIsProcessing(true);
    // TODO: Implémenter la logique de traitement des fichiers
    setIsProcessing(false);
  }, []);

  const handleExport = useCallback((format: string, maxSize?: number) => {
    // TODO: Implémenter la logique d'export
  }, [report]);

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 py-6">
          <div className="flex items-center space-x-3">
            <Camera className="w-8 h-8 text-blue-500" />
            <h1 className="text-2xl font-bold text-gray-900">
              Analyse Faciale
            </h1>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8 space-y-8">
        <FileUploader onFilesSelected={handleFilesSelected} />

        {isProcessing && (
          <div className="text-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mx-auto" />
            <p className="mt-4 text-gray-600">Traitement des fichiers en cours...</p>
          </div>
        )}

        {faces.length > 0 && (
          <section className="space-y-4">
            <h2 className="text-xl font-semibold">Visages détectés</h2>
            <FaceGrid faces={faces} onFaceSelect={setSelectedFace} />
          </section>
        )}

        {selectedFace && report && (
          <section className="space-y-4">
            <h2 className="text-xl font-semibold">Options d'export</h2>
            <ExportOptions report={report} onExport={handleExport} />
          </section>
        )}
      </main>
    </div>
  );
}

export default App;