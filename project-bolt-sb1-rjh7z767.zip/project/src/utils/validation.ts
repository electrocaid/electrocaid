/**
 * Validates if the provided size is within acceptable range
 * @param size - The size to validate in megabytes
 * @returns boolean indicating if the size is valid
 */
export const validateMaxSize = (size: number): boolean => {
  return size >= 1 && size <= 100;
};