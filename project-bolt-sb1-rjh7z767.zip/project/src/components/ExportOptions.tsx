import React, { useState } from 'react';
import { FileIcon, FileJson, FileSpreadsheetIcon, FileTextIcon, ImageIcon } from 'lucide-react';
import { AnalysisReport } from '../types';

interface ExportOptionsProps {
  report: AnalysisReport;
  onExport: (format: string, maxSize?: number) => void;
}

export const ExportOptions: React.FC<ExportOptionsProps> = ({ report, onExport }) => {
  const [maxSize, setMaxSize] = useState<number>(10);

  const exportFormats = [
    { id: 'json', icon: FileJson, label: 'JSON' },
    { id: 'csv', icon: FileSpreadsheetIcon, label: 'CSV' },
    { id: 'pdf', icon: FileTextIcon, label: 'PDF' },
    { id: 'gif', icon: ImageIcon, label: 'GIF' }
  ];

  return (
    <div className="space-y-4">
      <div className="flex items-center space-x-4">
        <label className="text-sm text-gray-600">
          Taille maximale (Mo):
        </label>
        <input
          type="number"
          min="1"
          max="100"
          value={maxSize}
          onChange={(e) => setMaxSize(Number(e.target.value))}
          className="w-20 px-2 py-1 border rounded"
        />
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {exportFormats.map(({ id, icon: Icon, label }) => (
          <button
            key={id}
            onClick={() => onExport(id, maxSize)}
            className="flex items-center justify-center space-x-2 p-3 border rounded-lg
              hover:bg-gray-50 transition-colors"
          >
            <Icon className="w-5 h-5" />
            <span>{label}</span>
          </button>
        ))}
      </div>
    </div>
  );
};