import type { LucideIcon } from 'lucide-react';
import type { AnalysisReport } from '../../types';

export interface ExportFormat {
  id: string;
  icon: LucideIcon;
  label: string;
}

export interface ExportOptionsProps {
  report: AnalysisReport;
  onExport: (format: string, maxSize: number) => void;
}