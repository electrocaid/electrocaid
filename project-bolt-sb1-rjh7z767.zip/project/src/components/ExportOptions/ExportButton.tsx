import React from 'react';
import { LucideIcon, Loader2 } from 'lucide-react';

interface ExportButtonProps {
  id: string;
  Icon: LucideIcon;
  label: string;
  onClick: () => void;
  loading?: boolean;
  disabled?: boolean;
}

export const ExportButton: React.FC<ExportButtonProps> = ({ 
  id, 
  Icon, 
  label, 
  onClick,
  loading = false,
  disabled = false 
}) => (
  <button
    type="button"
    onClick={onClick}
    disabled={disabled || loading}
    aria-label={`Exporter en ${label}`}
    title={`Exporter en ${label}`}
    className={`
      flex items-center justify-center space-x-2 p-3 border rounded-lg
      transition-all duration-200
      ${disabled || loading 
        ? 'opacity-50 cursor-not-allowed' 
        : 'hover:bg-gray-50 active:bg-gray-100'
      }
    `}
  >
    {loading ? (
      <Loader2 className="w-5 h-5 animate-spin" aria-hidden="true" />
    ) : (
      <Icon className="w-5 h-5" aria-hidden="true" />
    )}
    <span>{loading ? 'Export en cours...' : label}</span>
  </button>
);