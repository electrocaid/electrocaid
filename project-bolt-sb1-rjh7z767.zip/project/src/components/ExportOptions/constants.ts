import { FileJson, FileSpreadsheet, FileText, Image } from 'lucide-react';
import type { ExportFormat } from './types';

export const EXPORT_FORMATS: ExportFormat[] = [
  { id: 'json', icon: FileJson, label: 'JSON' },
  { id: 'csv', icon: FileSpreadsheet, label: 'CSV' },
  { id: 'pdf', icon: FileText, label: 'PDF' },
  { id: 'gif', icon: Image, label: 'GIF' }
];