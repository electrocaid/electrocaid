import React from 'react';
import { validateMaxSize } from '../../utils/validation';

interface MaxSizeInputProps {
  value: number;
  onChange: (value: number) => void;
}

export const MaxSizeInput: React.FC<MaxSizeInputProps> = ({ value, onChange }) => {
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newValue = Number(e.target.value);
    if (validateMaxSize(newValue)) {
      onChange(newValue);
    }
  };

  return (
    <div className="flex items-center space-x-4">
      <label htmlFor="max-size" className="text-sm text-gray-600">
        Taille maximale (Mo):
      </label>
      <input
        id="max-size"
        type="number"
        min="1"
        max="100"
        value={value}
        onChange={handleChange}
        className="w-20 px-2 py-1 border rounded"
      />
    </div>
  );
};