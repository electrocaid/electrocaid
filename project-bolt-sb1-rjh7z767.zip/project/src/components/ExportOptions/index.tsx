import React, { useState, useCallback } from 'react';
import { MaxSizeInput } from './MaxSizeInput';
import { ExportButton } from './ExportButton';
import { EXPORT_FORMATS } from './constants';
import type { ExportOptionsProps } from './types';

export const ExportOptions: React.FC<ExportOptionsProps> = ({ onExport }) => {
  const [maxSize, setMaxSize] = useState<number>(10);
  const [loadingFormat, setLoadingFormat] = useState<string | null>(null);

  const handleExport = useCallback((format: string) => {
    setLoadingFormat(format);
    onExport(format, maxSize);
    setTimeout(() => setLoadingFormat(null), 1000);
  }, [maxSize, onExport]);

  return (
    <div className="space-y-4">
      <MaxSizeInput value={maxSize} onChange={setMaxSize} />
      
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {EXPORT_FORMATS.map(({ id, icon, label }) => (
          <ExportButton
            key={id}
            id={id}
            Icon={icon}
            label={label}
            loading={loadingFormat === id}
            onClick={() => handleExport(id)}
          />
        ))}
      </div>
    </div>
  );
};