import React from 'react';
import { FaceData } from '../types';

interface FaceGridProps {
  faces: FaceData[];
  onFaceSelect: (face: FaceData) => void;
}

export const FaceGrid: React.FC<FaceGridProps> = ({ faces, onFaceSelect }) => {
  return (
    <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
      {faces.map((face) => (
        <div
          key={face.id}
          onClick={() => onFaceSelect(face)}
          className="relative aspect-square cursor-pointer group overflow-hidden rounded-lg"
        >
          <img
            src={face.imageUrl}
            alt="Visage détecté"
            className="object-cover w-full h-full transition-transform group-hover:scale-105"
          />
          <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-20 transition-opacity" />
        </div>
      ))}
    </div>
  );
};